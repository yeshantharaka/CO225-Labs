#include <stdio.h>

/* what ever the helper functions you need for the 
 * implementation of bigints
 * the prototypes goes here and the functions should be 
 * implemented in the helper.c
 */


