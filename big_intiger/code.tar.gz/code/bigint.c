#include <bigint.h>
#include <stdlib.h>

/* implement the functions in *.h 
 * Given are broken code!!!!!!!
 */ 


bigint_t new_bigint(int a) 
{

}


int add(bigint_t s, bigint_t a, bigint_t b)
{

}

void show_bigint(bigint_t v) 
{

}
  
